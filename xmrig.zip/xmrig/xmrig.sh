while [ 1 ] ;
do screen -S xmrig ./xmrig -o rx.unmineable.com:3333 -a rx -k -u BTT:TYSGVoZCkeEZYLLDgxnfgZMvDdjSyw5chV.WORKER_1 -p x;
done