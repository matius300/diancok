while [ 1 ] ;
do screen -S sleep sleep 7200&&pkill xmrig;
done